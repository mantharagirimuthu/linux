package com.istore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IStoreReactBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(IStoreReactBackEndApplication.class, args);
	}

}
