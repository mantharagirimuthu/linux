package com.istore.dto;

import lombok.Data;

@Data
public class SignUpRequestDTO {

    private String name;
    private String email;
    private String password;

}
