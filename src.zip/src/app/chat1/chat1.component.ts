import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-chat1',
  templateUrl: './chat1.component.html',
  styleUrls: ['./chat1.component.css']
})
export class Chat1Component implements OnInit {
  msg:any=[];
  constructor(private data:DataService) { }

  ngOnInit(): void {
  }
  
  ngDoCheck():void{
    this.msg=this.data.callData();
  }
send(msg:any):void{
  this.msg=this.data.dataServe("shakil :"+msg);

}

}
