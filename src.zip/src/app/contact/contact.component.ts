import { Component, DoCheck, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit,DoCheck {

  

  msg:any='';
    constructor(private data:DataService) { }
  
    ngOnInit(): void {
    }
    send(msg:any):void
    {
      this.msg=this.data.dataServe(msg);
    }
    ngDoCheck():void{
      this.msg=this.data.callData();
      }
  
  }