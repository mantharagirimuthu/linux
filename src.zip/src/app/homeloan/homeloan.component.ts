import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeloan',
  templateUrl: './homeloan.component.html',
  styleUrls: ['./homeloan.component.css']
})
export class HomeloanComponent implements OnInit {

  
    val:string="";
    va:string="";
    value:string="";
    flag:boolean=false;
      constructor() { }
    
      ngOnInit(): void {
      }
    
      home(b:any,b2:any){
        this.va=`${Math.round(b*b2*0.05)}`;
      }
     
}
