import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

message:string='';
  constructor() { }

  dataServe(msg:any):void{
    console.log("this msg is from data service " +msg)
    this.message=msg;
  }
  callData():string{
    return this.message;
  }
}
