import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-person1',
  templateUrl: './person1.component.html',
  styleUrls: ['./person1.component.css']
})
export class Person1Component implements OnInit {
  msg:string='';


  constructor(private data:DataService) { }

  ngOnInit(): void {
  }
send(msg:any):void{
  this.data.dataServe(msg);
  this.msg=`${msg}`;
}
}
