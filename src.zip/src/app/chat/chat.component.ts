import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  
    msg:any=[];
  
  
    constructor(private data:DataService) { }
  
    ngOnInit(): void {
    }
    ngDoCheck():void{
      this.msg=this.data.callData();
    }
  send(msg:any):void{
    this.msg=this.data.dataServe("giri :"+msg);
  
  }
  
  }
  

