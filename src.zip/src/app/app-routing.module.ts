import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CarloanComponent } from './carloan/carloan.component';
import { ChatComponent } from './chat/chat.component';
import { ChatappComponent } from './chatapp/chatapp.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { HomeloanComponent } from './homeloan/homeloan.component';
import { LoginComponent } from './login/login.component';
import { PersonalloanComponent } from './personalloan/personalloan.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'carloan',component:CarloanComponent},
  {path:'homeloan',component:HomeloanComponent},
  {path:'personalloan',component:PersonalloanComponent},
  {path:'contact',component:ContactComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'chatapp',component:ChatappComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
