import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carloan',
  templateUrl: './carloan.component.html',
  styleUrls: ['./carloan.component.css']
})
export class CarloanComponent implements OnInit {


    val:string="";
    va:string="";
    value:string="";
    flag:boolean=false;
     
      ngOnInit(): void {
      }
      car(v:any,v2:any){
        this.val=`${Math.round(v*v2*0.07)}`;
      }
  

}
