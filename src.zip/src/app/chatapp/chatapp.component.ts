import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatapp',
  templateUrl: './chatapp.component.html',
  styleUrls: ['./chatapp.component.css']
})
export class ChatappComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
