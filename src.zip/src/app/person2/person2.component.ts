import { Component, OnInit,DoCheck } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-person2',
  templateUrl: './person2.component.html',
  styleUrls: ['./person2.component.css']
})
export class Person2Component implements OnInit,DoCheck {
msg:string='';
  constructor(private dataserice:DataService) { }

  ngOnInit(): void {
  }
ngDoCheck():void{
  this.msg=this.dataserice.callData();
}
}
