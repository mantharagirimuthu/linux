import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personalloan',
  templateUrl: './personalloan.component.html',
  styleUrls: ['./personalloan.component.css']
})
export class PersonalloanComponent implements OnInit {
  
  
    val:string="";
    va:string="";
    value:string="";
    flag:boolean=false;
    ngOnInit(): void {

    }
  
     
      Personal(c:any,c2:any){
        this.value=`${Math.round(c*c2*0.04)}`;
      }
}
