import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  flag: boolean | undefined;

  constructor() { }

  ngOnInit(): void {
  }
  changes(){
    if(this.flag){
      this.flag=!this.flag; }
    else{
        this.flag=!this.flag;
      }
}


}
