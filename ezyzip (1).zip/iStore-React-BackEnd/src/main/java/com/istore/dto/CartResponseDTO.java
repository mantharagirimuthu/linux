package com.istore.dto;

import java.util.List;

import lombok.Data;

@Data
public class CartResponseDTO {

    private List<ProductDTO> products;

}
