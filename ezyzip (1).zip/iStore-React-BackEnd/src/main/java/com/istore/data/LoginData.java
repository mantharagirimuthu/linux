package com.istore.data;

import com.istore.dto.LoginResponseDTO;

import lombok.Data;

@Data
public class LoginData {

    private LoginResponseDTO user;

}
